﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dataGridView1 = New System.Windows.Forms.DataGridView()
        Me.REF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ADI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SOYADI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MEMLEKET = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GELIR = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GIDER = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.radioButton2 = New System.Windows.Forms.RadioButton()
        Me.radioButton1 = New System.Windows.Forms.RadioButton()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.textBox4 = New System.Windows.Forms.TextBox()
        Me.textBox3 = New System.Windows.Forms.TextBox()
        Me.comboBox1 = New System.Windows.Forms.ComboBox()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        CType(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dataGridView1
        '
        Me.dataGridView1.AllowUserToAddRows = False
        Me.dataGridView1.AllowUserToDeleteRows = False
        Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.REF, Me.ADI, Me.SOYADI, Me.MEMLEKET, Me.GELIR, Me.GIDER})
        Me.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.dataGridView1.Location = New System.Drawing.Point(0, 286)
        Me.dataGridView1.Name = "dataGridView1"
        Me.dataGridView1.ReadOnly = True
        Me.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dataGridView1.Size = New System.Drawing.Size(1146, 341)
        Me.dataGridView1.TabIndex = 79
        '
        'REF
        '
        Me.REF.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.REF.DataPropertyName = "REFNO"
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        Me.REF.DefaultCellStyle = DataGridViewCellStyle1
        Me.REF.HeaderText = "REFNO"
        Me.REF.Name = "REF"
        Me.REF.ReadOnly = True
        '
        'ADI
        '
        Me.ADI.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.ADI.DataPropertyName = "ADI"
        Me.ADI.HeaderText = "ADI"
        Me.ADI.Name = "ADI"
        Me.ADI.ReadOnly = True
        '
        'SOYADI
        '
        Me.SOYADI.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.SOYADI.DataPropertyName = "SOYADI"
        Me.SOYADI.HeaderText = "SOYADI"
        Me.SOYADI.Name = "SOYADI"
        Me.SOYADI.ReadOnly = True
        '
        'MEMLEKET
        '
        Me.MEMLEKET.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.MEMLEKET.DataPropertyName = "MEMLEKET"
        Me.MEMLEKET.HeaderText = "MEMLEKET"
        Me.MEMLEKET.Name = "MEMLEKET"
        Me.MEMLEKET.ReadOnly = True
        '
        'GELIR
        '
        Me.GELIR.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.GELIR.DataPropertyName = "GELIR"
        Me.GELIR.HeaderText = "GELIR"
        Me.GELIR.Name = "GELIR"
        Me.GELIR.ReadOnly = True
        '
        'GIDER
        '
        Me.GIDER.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.GIDER.DataPropertyName = "GIDER"
        Me.GIDER.HeaderText = "GIDER"
        Me.GIDER.Name = "GIDER"
        Me.GIDER.ReadOnly = True
        '
        'radioButton2
        '
        Me.radioButton2.AutoSize = True
        Me.radioButton2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.radioButton2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radioButton2.Location = New System.Drawing.Point(809, 145)
        Me.radioButton2.Name = "radioButton2"
        Me.radioButton2.Size = New System.Drawing.Size(275, 33)
        Me.radioButton2.TabIndex = 78
        Me.radioButton2.TabStop = True
        Me.radioButton2.Text = "Seçili Kaydı Raporla"
        Me.radioButton2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.radioButton2.UseVisualStyleBackColor = True
        '
        'radioButton1
        '
        Me.radioButton1.AutoSize = True
        Me.radioButton1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.radioButton1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radioButton1.Location = New System.Drawing.Point(809, 181)
        Me.radioButton1.Name = "radioButton1"
        Me.radioButton1.Size = New System.Drawing.Size(226, 33)
        Me.radioButton1.TabIndex = 77
        Me.radioButton1.TabStop = True
        Me.radioButton1.Text = "Hepsini Raporla"
        Me.radioButton1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.radioButton1.UseVisualStyleBackColor = True
        '
        'button3
        '
        Me.button3.BackColor = System.Drawing.SystemColors.HotTrack
        Me.button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.button3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.button3.Location = New System.Drawing.Point(602, 134)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(201, 80)
        Me.button3.TabIndex = 76
        Me.button3.Text = "RAPORLA"
        Me.button3.UseVisualStyleBackColor = False
        '
        'button2
        '
        Me.button2.BackColor = System.Drawing.SystemColors.HotTrack
        Me.button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.button2.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.button2.Location = New System.Drawing.Point(384, 130)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(211, 84)
        Me.button2.TabIndex = 75
        Me.button2.Text = "SİL"
        Me.button2.UseVisualStyleBackColor = False
        '
        'button1
        '
        Me.button1.BackColor = System.Drawing.SystemColors.HotTrack
        Me.button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.button1.Location = New System.Drawing.Point(384, 40)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(211, 84)
        Me.button1.TabIndex = 74
        Me.button1.Text = "KAYDET"
        Me.button1.UseVisualStyleBackColor = False
        '
        'textBox4
        '
        Me.textBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.textBox4.Location = New System.Drawing.Point(174, 123)
        Me.textBox4.Name = "textBox4"
        Me.textBox4.Size = New System.Drawing.Size(191, 35)
        Me.textBox4.TabIndex = 68
        '
        'textBox3
        '
        Me.textBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.textBox3.Location = New System.Drawing.Point(174, 165)
        Me.textBox3.Name = "textBox3"
        Me.textBox3.Size = New System.Drawing.Size(191, 35)
        Me.textBox3.TabIndex = 70
        '
        'comboBox1
        '
        Me.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBox1.FormattingEnabled = True
        Me.comboBox1.Location = New System.Drawing.Point(174, 207)
        Me.comboBox1.Name = "comboBox1"
        Me.comboBox1.Size = New System.Drawing.Size(191, 37)
        Me.comboBox1.TabIndex = 71
        '
        'textBox2
        '
        Me.textBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.textBox2.Location = New System.Drawing.Point(174, 80)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(191, 35)
        Me.textBox2.TabIndex = 65
        '
        'textBox1
        '
        Me.textBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.textBox1.Location = New System.Drawing.Point(174, 40)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(191, 35)
        Me.textBox1.TabIndex = 64
        '
        'label5
        '
        Me.label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label5.Location = New System.Drawing.Point(21, 211)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(147, 32)
        Me.label5.TabIndex = 84
        Me.label5.Text = "Memleket"
        Me.label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'label4
        '
        Me.label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label4.Location = New System.Drawing.Point(77, 168)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(90, 32)
        Me.label4.TabIndex = 83
        Me.label4.Text = "Gider"
        Me.label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'label3
        '
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label3.Location = New System.Drawing.Point(87, 126)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(81, 32)
        Me.label3.TabIndex = 82
        Me.label3.Text = "Gelir"
        Me.label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label2.Location = New System.Drawing.Point(46, 84)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(121, 32)
        Me.label2.TabIndex = 81
        Me.label2.Text = "Soyisim"
        Me.label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label1.Location = New System.Drawing.Point(97, 40)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(70, 32)
        Me.label1.TabIndex = 80
        Me.label1.Text = "İsim"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(15.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.ClientSize = New System.Drawing.Size(1146, 627)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.dataGridView1)
        Me.Controls.Add(Me.radioButton2)
        Me.Controls.Add(Me.radioButton1)
        Me.Controls.Add(Me.button3)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.textBox4)
        Me.Controls.Add(Me.textBox3)
        Me.Controls.Add(Me.comboBox1)
        Me.Controls.Add(Me.textBox2)
        Me.Controls.Add(Me.textBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Veri Kontrol Ekranı"
        CType(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents dataGridView1 As System.Windows.Forms.DataGridView
    Private WithEvents REF As System.Windows.Forms.DataGridViewTextBoxColumn
    Private WithEvents ADI As System.Windows.Forms.DataGridViewTextBoxColumn
    Private WithEvents SOYADI As System.Windows.Forms.DataGridViewTextBoxColumn
    Private WithEvents MEMLEKET As System.Windows.Forms.DataGridViewTextBoxColumn
    Private WithEvents GELIR As System.Windows.Forms.DataGridViewTextBoxColumn
    Private WithEvents GIDER As System.Windows.Forms.DataGridViewTextBoxColumn
    Private WithEvents radioButton2 As System.Windows.Forms.RadioButton
    Private WithEvents radioButton1 As System.Windows.Forms.RadioButton
    Private WithEvents button3 As System.Windows.Forms.Button
    Private WithEvents button2 As System.Windows.Forms.Button
    Private WithEvents button1 As System.Windows.Forms.Button
    Private WithEvents textBox4 As System.Windows.Forms.TextBox
    Private WithEvents textBox3 As System.Windows.Forms.TextBox
    Private WithEvents comboBox1 As System.Windows.Forms.ComboBox
    Private WithEvents textBox2 As System.Windows.Forms.TextBox
    Private WithEvents textBox1 As System.Windows.Forms.TextBox
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
End Class
