﻿Imports System.Data.OleDb
Imports System.IO
Imports Microsoft.VisualBasic

Public Class Form2

    ' Form yüklendiğinde yapılacak işlemler
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Guncelle() ' DataGridView güncelle
        ComboBox1.Items.AddRange(File.ReadAllLines("memleket.txt")) ' memleket.txt'den memleketleri çek
    End Sub

    ' Sadece harf (ve büyük harfe dönüştürerek) giriş kontrolü - Müşteri Adı
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        e.Handled = Not Char.IsLetter(e.KeyChar) And Not Char.IsControl(e.KeyChar)
        TextBox1.CharacterCasing = CharacterCasing.Upper ' Büyük harf
    End Sub

    ' Sadece harf (ve büyük harfe dönüştürerek) giriş kontrolü - Müşteri Soyadı
    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        e.Handled = Not Char.IsLetter(e.KeyChar) And Not Char.IsControl(e.KeyChar)
        TextBox2.CharacterCasing = CharacterCasing.Upper ' Büyük harf
    End Sub

    ' Sadece sayı giriş kontrolü - Gelir
    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        e.Handled = Not Char.IsDigit(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub

    ' Sadece sayı giriş kontrolü - Gider
    Private Sub TextBox4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox4.KeyPress
        e.Handled = Not Char.IsDigit(e.KeyChar) And Not Char.IsControl(e.KeyChar)
    End Sub

    ' DataGridView güncelleme metodu
    Sub Guncelle()
        Dim tablo As New DataTable()
        Dim adaptor As New OleDbDataAdapter("SELECT * FROM veriler", Form1.baglan)
        adaptor.Fill(tablo)
        DataGridView1.DataSource = tablo
    End Sub

    ' REFNO oluşturma fonksiyonu (güncellendi)
    Function RefnoOlustur(ad As String) As String
        Dim refno As String = ad.Substring(0, 1) & DateTime.Now.Year.ToString()
        Dim rastgele As New Random()
        Dim kalanHarfler As String = ad.Substring(1) ' İlk harfi çıkar

        For i As Integer = 1 To kalanHarfler.Length
            Dim rastgeleIndex As Integer = rastgele.Next(0, kalanHarfler.Length)
            refno &= kalanHarfler(rastgeleIndex)
        Next
        Return refno
    End Function

    ' Kayıt ekleme işlemi
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Bilgileri al
        Dim ad As String = TextBox1.Text.ToUpper().Trim()
        Dim soyad As String = TextBox2.Text.ToUpper().Trim()
        Dim memleket As String = ComboBox1.Text
        Dim gelir As Double = Val(TextBox3.Text)
        Dim gider As Double = Val(TextBox4.Text)

        ' Eksik bilgi kontrolü
        If ad = "" Or soyad = "" Then
            MessageBox.Show("Ad ve Soyad boş olamaz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' REFNO oluştur
        Dim refno As String = RefnoOlustur(ad)

        ' REFNO kontrolü (aynı REFNO varsa tekrar oluştur)
        Dim kontrol As New OleDbCommand("SELECT COUNT(*) FROM veriler WHERE REFNO=@R", Form1.baglan)
        kontrol.Parameters.AddWithValue("@R", refno)

        If Form1.baglan.State = ConnectionState.Closed Then
            Form1.baglan.Open()
        End If

        Dim say As Integer = Convert.ToInt32(kontrol.ExecuteScalar())

        If Form1.baglan.State = ConnectionState.Open Then
            Form1.baglan.Close()
        End If

        If say > 0 Then
            MessageBox.Show("Bu REFNO zaten mevcut. Lütfen tekrar deneyin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Komut tanımı
        Dim kaydet As New OleDbCommand("INSERT INTO veriler (REFNO, ADI, SOYADI, MEMLEKET, GELIR, GIDER) VALUES (@refno, @adi, @soyadi, @memleket, @gelir, @gider)", Form1.baglan)
        kaydet.Parameters.AddWithValue("@refno", refno) ' REFNO parametresini ekle
        kaydet.Parameters.AddWithValue("@adi", ad)
        kaydet.Parameters.AddWithValue("@soyadi", soyad)
        kaydet.Parameters.AddWithValue("@memleket", memleket)
        kaydet.Parameters.AddWithValue("@gelir", gelir)
        kaydet.Parameters.AddWithValue("@gider", gider)

        ' Bağlantı kontrolü
        If Form1.baglan.State = ConnectionState.Closed Then
            Form1.baglan.Open()
        End If

        ' Kayıt işlemi
        kaydet.ExecuteNonQuery()

        ' Bağlantıyı kapat
        If Form1.baglan.State = ConnectionState.Open Then
            Form1.baglan.Close()
        End If

        MessageBox.Show(ad & " isimli kullanıcı kaydedilmiştir!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information)

        ' Listeyi güncelle
        Guncelle()
        ' Alanları temizle
        Temizle()
    End Sub

    ' Silme işlemi
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim refno = InputBox("Silinecek kaydın REFNO'sunu giriniz:", "REFNO").ToUpper().Trim()
        If refno = "" Then Return

        ' REFNO kontrol
        Dim kontrol As New OleDbCommand("SELECT COUNT(*) FROM veriler WHERE REFNO=@R", Form1.baglan)
        kontrol.Parameters.AddWithValue("@R", refno)

        ' Bağlantı kontrol edilerek açılır
        If Form1.baglan.State = ConnectionState.Closed Then
            Form1.baglan.Open()
        End If

        Dim say As Integer = Convert.ToInt32(kontrol.ExecuteScalar())

        ' Bağlantı kapatılır
        If Form1.baglan.State = ConnectionState.Open Then
            Form1.baglan.Close()
        End If

        If say = 0 Then
            MessageBox.Show("Bu REFNO'ya sahip kayıt bulunamadı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Silme onayı
        Dim cevap = MessageBox.Show("Kaydı silmek istediğinizden emin misiniz?", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If cevap = DialogResult.Yes Then
            Dim silKomut As New OleDbCommand("DELETE FROM veriler WHERE REFNO=@R", Form1.baglan)
            silKomut.Parameters.AddWithValue("@R", refno)

            If Form1.baglan.State = ConnectionState.Closed Then
                Form1.baglan.Open()
            End If

            silKomut.ExecuteNonQuery()

            If Form1.baglan.State = ConnectionState.Open Then
                Form1.baglan.Close()
            End If

            MessageBox.Show("Kayıt silindi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Guncelle()
        End If
    End Sub

    ' Raporlama işlemi
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If RadioButton1.Checked Then
            ' Tüm bilgileri raporla
            Dim form3 As New Form3()
            form3.ShowDialog()
        ElseIf RadioButton2.Checked Then
            ' Belirli kayıt raporla
            Dim refno = InputBox("Raporlanacak kaydın REFNO'sunu giriniz:", "REFNO").ToUpper().Trim()
            If refno <> "" Then
                Dim form3 As New Form3(refno)
                form3.ShowDialog()
            End If
        Else
            MessageBox.Show("Lütfen raporlanacak bilgileri seçiniz!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub


    ' Alanları temizle
    Sub Temizle()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        ComboBox1.SelectedIndex = -1
    End Sub


End Class