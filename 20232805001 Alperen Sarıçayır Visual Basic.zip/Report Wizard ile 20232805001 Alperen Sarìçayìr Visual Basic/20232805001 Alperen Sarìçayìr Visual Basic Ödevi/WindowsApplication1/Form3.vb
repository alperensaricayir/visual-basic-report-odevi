﻿Imports System.Data.OleDb
Imports Microsoft.Reporting.WinForms

Public Class Form3
    Private refNo As String

    Public Sub New()
        InitializeComponent()
        refNo = Nothing
    End Sub

    Public Sub New(ByVal gelenRefNo As String)
        InitializeComponent()
        refNo = gelenRefNo
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Dim bag As New OleDbConnection("Provider=Microsoft.Ace.Oledb.12.0; Data Source=bilgiler.accdb")

        Dim sql As String

        If String.IsNullOrEmpty(refNo) Then
            sql = "SELECT * FROM veriler" ' Tüm verileri getir
        Else
            sql = "SELECT * FROM veriler WHERE RefNo = ?"
        End If

        Dim adaptor As New OleDbDataAdapter(sql, bag)

        If Not String.IsNullOrEmpty(refNo) Then
            adaptor.SelectCommand.Parameters.AddWithValue("?", refNo)
        End If

        Dim dataSet As New DataSet()
        adaptor.Fill(dataSet, "veriler")

        Dim rapor As New ReportDataSource("DataSet1", dataSet.Tables("veriler"))
        reportViewer1.LocalReport.DataSources.Clear()
        reportViewer1.LocalReport.DataSources.Add(rapor)
        reportViewer1.RefreshReport()
    End Sub
End Class
