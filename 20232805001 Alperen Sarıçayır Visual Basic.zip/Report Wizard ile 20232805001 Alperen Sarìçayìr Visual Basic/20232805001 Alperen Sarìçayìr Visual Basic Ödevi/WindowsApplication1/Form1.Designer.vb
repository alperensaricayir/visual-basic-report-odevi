﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblHosGeldiniz = New System.Windows.Forms.Label()
        Me.lblSifre = New System.Windows.Forms.Label()
        Me.lblKullaniciAdi = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(371, 211)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(217, 35)
        Me.TextBox1.TabIndex = 0
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(372, 252)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(217, 35)
        Me.TextBox2.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button1.Location = New System.Drawing.Point(371, 332)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(217, 78)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "GİRİŞ"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lblHosGeldiniz
        '
        Me.lblHosGeldiniz.AutoSize = True
        Me.lblHosGeldiniz.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.lblHosGeldiniz.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblHosGeldiniz.Location = New System.Drawing.Point(245, 110)
        Me.lblHosGeldiniz.Name = "lblHosGeldiniz"
        Me.lblHosGeldiniz.Size = New System.Drawing.Size(419, 59)
        Me.lblHosGeldiniz.TabIndex = 14
        Me.lblHosGeldiniz.Text = "HOŞ GELDİNİZ."
        '
        'lblSifre
        '
        Me.lblSifre.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblSifre.Location = New System.Drawing.Point(283, 255)
        Me.lblSifre.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblSifre.Name = "lblSifre"
        Me.lblSifre.Size = New System.Drawing.Size(81, 32)
        Me.lblSifre.TabIndex = 16
        Me.lblSifre.Text = "Şifre"
        Me.lblSifre.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblKullaniciAdi
        '
        Me.lblKullaniciAdi.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblKullaniciAdi.Location = New System.Drawing.Point(181, 214)
        Me.lblKullaniciAdi.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblKullaniciAdi.Name = "lblKullaniciAdi"
        Me.lblKullaniciAdi.Size = New System.Drawing.Size(183, 32)
        Me.lblKullaniciAdi.TabIndex = 15
        Me.lblKullaniciAdi.Text = "Kullanıcı Adı"
        Me.lblKullaniciAdi.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.CheckBox1.Location = New System.Drawing.Point(371, 293)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(198, 33)
        Me.CheckBox1.TabIndex = 17
        Me.CheckBox1.Text = "Şifreyi Göster"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(15.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.ClientSize = New System.Drawing.Size(959, 496)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.lblSifre)
        Me.Controls.Add(Me.lblKullaniciAdi)
        Me.Controls.Add(Me.lblHosGeldiniz)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.ForeColor = System.Drawing.SystemColors.Highlight
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Kullanıcı Giriş"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Private WithEvents lblHosGeldiniz As System.Windows.Forms.Label
    Private WithEvents lblSifre As System.Windows.Forms.Label
    Private WithEvents lblKullaniciAdi As System.Windows.Forms.Label
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox

End Class
