﻿Imports System.Data.OleDb

Public Class Form1
    Public Sub New()
        InitializeComponent()
    End Sub

    Public Shared baglan As New OleDbConnection("Provider=Microsoft.Ace.Oledb.12.0; Data Source=bilgiler.accdb")

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Then
            MessageBox.Show("Lütfen kullanıcı adı giriniz.", "KULLANICI ADI")
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            MessageBox.Show("Lütfen şifre giriniz!", "ŞİFRE")
            Exit Sub
        End If
        Dim komut As New OleDbCommand("Select Count (*) From admin Where KULLANICI='" & TextBox1.Text & "' and SIFRE='" & TextBox2.Text & "'", baglan)
        baglan.Open()
        Dim sayi As Integer = Convert.ToInt32(komut.ExecuteScalar())
        If sayi = 1 Then
            MessageBox.Show("KULLANICI ADI VE ŞİFRESİ DOĞRULANDI...", "BAŞARILI")
            Dim form2 As New Form2()
            Me.Hide()
            form2.ShowDialog()
            Me.Close()
        Else

            MessageBox.Show("YANLIŞ KULLANICI ADI VEYA ŞİFRE", "HATALI GİRİŞ")
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox1.Focus()
        End If

        baglan.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If CheckBox1.Checked Then
            TextBox2.PasswordChar = ControlChars.NullChar ' Şifreyi göster
        Else
            TextBox2.PasswordChar = "*"c ' Şifreyi gizle
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            TextBox2.PasswordChar = ControlChars.NullChar ' Şifreyi göster
        Else
            TextBox2.PasswordChar = "*"c ' Şifreyi gizle
        End If
    End Sub
End Class
