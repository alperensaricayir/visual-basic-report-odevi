﻿Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports System.Diagnostics ' Debug.WriteLine için ekledik

Public Class Form4
    Public refNo As String = ""

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Not String.IsNullOrEmpty(refNo) Then
            Try
                ' Debug için refNo değerini kontrol et
                Debug.WriteLine("Form4_Load: refNo = " & refNo)

                ' Veritabanı bağlantısı
                Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Musteriler.accdb;"
                Using conn As New OleDbConnection(connectionString)
                    conn.Open()

                    ' Verileri çekmek için SQL sorgusu (RefNo'ya göre filtreleme)
                    Dim query As String = "SELECT * FROM Musteriler WHERE RefNo = ?"
                    Using cmd As New OleDbCommand(query, conn)
                        cmd.Parameters.AddWithValue("?", refNo)

                        ' Verileri DataTable'a aktar
                        Dim adapter As New OleDbDataAdapter(cmd)
                        Dim dt As New DataTable()
                        adapter.Fill(dt)

                        ' Debug için DataTable'ın satır sayısını kontrol et
                        Debug.WriteLine("Form4_Load: DataTable row count = " & dt.Rows.Count)

                        ' Crystal Report nesnesi oluştur (CrystalReport2 adında bir raporunuz olduğunu varsayıyorum)
                        Dim report As New CrystalReport2()

                        ' Raporun veri kaynağını ayarla
                        report.SetDataSource(dt)

                        ' CrystalReportViewer'da raporu göster (CrystalReportViewer1 adında bir görüntüleyiciniz olduğunu varsayıyorum)
                        CrystalReportViewer1.ReportSource = report
                        CrystalReportViewer1.Refresh()

                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show("Rapor yükleme hatası: " & ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Close()
            End Try
        Else
            MessageBox.Show("RefNo değeri alınamadı!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        End If
    End Sub
End Class