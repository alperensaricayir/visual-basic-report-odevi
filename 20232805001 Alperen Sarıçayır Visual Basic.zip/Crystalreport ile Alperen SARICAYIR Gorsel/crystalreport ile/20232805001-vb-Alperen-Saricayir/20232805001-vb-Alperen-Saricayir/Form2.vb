﻿Imports System.Data.OleDb
Imports System.Diagnostics ' Debug.WriteLine için ekledik

Public Class Form2

    Public Sub New()
        InitializeComponent()
    End Sub

    ' Rastgele 3 karakterle RefNo oluşturma fonksiyonu
    Private Function GenerateRefNo(musteriAdi As String) As String
        Dim rand As New Random()
        Dim yil As String = DateTime.Now.Year.ToString()
        Dim ilkHarf As String = musteriAdi.Substring(0, 1).ToUpper() ' Adın ilk harfi

        ' Adın harflerinden rastgele 3 harf seçimi
        Dim randomString As String = ""
        For i As Integer = 0 To 2
            Dim index As Integer = rand.Next(0, musteriAdi.Length)
            randomString &= musteriAdi(index).ToString().ToUpper() ' Karakterler büyük olacak
        Next

        ' Final RefNo: Örnek M2025ATA
        Return String.Format("{0}{1}{2}", ilkHarf, yil, randomString)
    End Function

    ' Veritabanında Referans Numarası var mı kontrolü
    Private Function RefNoVarMi(refNo As String) As Boolean
        Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Musteriler.accdb;"
        Using conn As New OleDbConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT COUNT(*) FROM Musteriler WHERE RefNo = ?"
                Using cmd As New OleDbCommand(query, conn)
                    cmd.Parameters.AddWithValue("?", refNo)
                    Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                    Return count > 0
                End Using
            Catch ex As Exception
                Debug.WriteLine("RefNoVarMi Hatası: " & ex.Message) ' Hata ayıklama için
                Return False
            End Try
        End Using
    End Function

    Private Sub LoadData()
        Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Musteriler.accdb;"
        Using conn As New OleDbConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT * FROM Musteriler"
                Dim adapter As New OleDbDataAdapter(query, conn)
                Dim dt As New DataTable()
                adapter.Fill(dt)
                dataGridView1.DataSource = dt
            Catch ex As Exception
                MessageBox.Show("Veri yükleme hatası: " & ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Sub btnKaydet_Click(sender As Object, e As EventArgs) Handles btnKaydet.Click
        LoadData()

        Dim musteriAdi As String = txtMusteriAdi.Text.Trim()
        Dim musteriSoyadi As String = txtMusteriSoyadi.Text.Trim()
        Dim gelir As String = txtGelir.Text.Trim()
        Dim gider As String = txtGider.Text.Trim()
        Dim memleket As String = If(comboMemleket.SelectedItem IsNot Nothing, comboMemleket.SelectedItem.ToString(), String.Empty)

        ' Alanlar boş mu kontrol et
        If String.IsNullOrEmpty(musteriAdi) OrElse String.IsNullOrEmpty(musteriSoyadi) OrElse
           String.IsNullOrEmpty(gelir) OrElse String.IsNullOrEmpty(gider) OrElse String.IsNullOrEmpty(memleket) Then
            MessageBox.Show("Tüm alanlar doldurulmalıdır!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Referans numarasını oluştur
        Dim refNo As String = GenerateRefNo(musteriAdi)

        ' Veritabanı kontrolü
        If RefNoVarMi(refNo) Then
            MessageBox.Show("Bu referans numarası zaten mevcut. Lütfen tekrar deneyin.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Kullanıcıya kaydetme onayı ver
        Dim dialogResult As DialogResult = MessageBox.Show(String.Format("{0} isimli kişiyi kaydetmek istiyor musunuz?", musteriAdi), "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = dialogResult.Yes Then
            ' Veritabanına kaydet
            Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Musteriler.accdb;"
            Using conn As New OleDbConnection(connectionString)
                Try
                    conn.Open()
                    Dim query As String = "INSERT INTO Musteriler (RefNo, [Müşteri Adı], [Müşteri Soyadı], Gelir, Gider, Memleket) VALUES (?, ?, ?, ?, ?, ?)"
                    Using cmd As New OleDbCommand(query, conn)
                        cmd.Parameters.AddWithValue("?", refNo)
                        cmd.Parameters.AddWithValue("?", musteriAdi)
                        cmd.Parameters.AddWithValue("?", musteriSoyadi)
                        cmd.Parameters.AddWithValue("?", gelir)
                        cmd.Parameters.AddWithValue("?", gider)
                        cmd.Parameters.AddWithValue("?", memleket)

                        cmd.ExecuteNonQuery()

                    End Using

                    MessageBox.Show("Müşteri başarıyla kaydedildi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    LoadData()
                Catch ex As Exception
                    MessageBox.Show("Veritabanı hatası: " & ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End Using
        End If
        ' DataGridView'i en alta kaydır
        If dataGridView1.Rows.Count > 0 Then
            dataGridView1.FirstDisplayedScrollingRowIndex = dataGridView1.RowCount - 1
        End If
        LoadData()

    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadData()
        ' ComboBox için memleket verilerini yükle
        Dim memleketler() As String = System.IO.File.ReadAllLines("memleketler.txt")
        comboMemleket.Items.AddRange(memleketler)
        btnRaporla.Enabled = False ' Form yüklendiğinde butonu devre dışı bırak
    End Sub

    Private Sub txtMusteriSoyadi_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMusteriSoyadi.KeyPress
        ' Sadece büyük harf ve boşluk karakterine izin ver
        If Not Char.IsLetter(e.KeyChar) AndAlso e.KeyChar <> " "c AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True ' Geçersiz karakteri engelle
        End If

        ' Küçük harflerin girişini engelle
        If Char.IsLower(e.KeyChar) Then
            e.KeyChar = Char.ToUpper(e.KeyChar) ' Küçük harfi büyük harfe çevir
        End If
    End Sub

    Private Sub txtGelir_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtGelir.KeyPress
        ' Sayı girilmesine izin ver
        If Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> ChrW(8) Then ' 8, backspace tuşu
            e.Handled = True ' Geçersiz karakteri engelle
        End If
    End Sub

    Private Sub txtGider_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtGider.KeyPress
        ' Sayı girilmesine izin ver
        If Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> ChrW(8) Then ' 8, backspace tuşu
            e.Handled = True ' Geçersiz karakteri engelle
        End If
    End Sub

    Private Sub txtMusteriAdi_KeyPress_1(sender As Object, e As KeyPressEventArgs) Handles txtMusteriAdi.KeyPress
        If Not Char.IsLetter(e.KeyChar) AndAlso e.KeyChar <> " "c AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If

        If Char.IsLower(e.KeyChar) Then
            e.KeyChar = Char.ToUpper(e.KeyChar)
        End If
    End Sub

    Private Sub btnSil_Click(sender As Object, e As EventArgs) Handles btnSil.Click
        ' Silme işlemi
        Dim refNo As String = InputBox("Silinecek kişinin RefNo'sunu girin:", "Kayıt Silme", "")
        If String.IsNullOrEmpty(refNo) Then
            MessageBox.Show("RefNo boş olamaz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Veritabanında refNo'yu kontrol et
        If Not RefNoVarMi(refNo) Then
            MessageBox.Show("Bu RefNo ile bir kayıt bulunamadı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Kaydı silme
        Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Musteriler.accdb;"
        Using conn As New OleDbConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "DELETE FROM Musteriler WHERE RefNo = ?"
                Using cmd As New OleDbCommand(query, conn)
                    cmd.Parameters.AddWithValue("?", refNo)
                    cmd.ExecuteNonQuery()
                End Using

                MessageBox.Show("Kayıt başarıyla silindi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadData()
            Catch ex As Exception
                MessageBox.Show("Veritabanı hatası: " & ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
        LoadData()

    End Sub

    Private Sub btnRaporla_Click(sender As Object, e As EventArgs) Handles btnRaporla.Click
        If radioBtnArananKayit.Checked Then
            ' Kullanıcıdan RefNo al
            Dim refNo As String = InputBox("Raporlamak istediğiniz kaydın RefNo'sunu girin:", "Kayıt Raporlama", "")

            ' Kullanıcı boş bırakırsa işlem yapma
            If String.IsNullOrEmpty(refNo) Then
                MessageBox.Show("RefNo girilmedi!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' RefNo'nun veritabanında olup olmadığını kontrol et
            If RefNoVarMi(refNo) Then
                Dim form4 As New Form4()
                form4.refNo = refNo ' Form4'te kullanılmak üzere RefNo değerini ata
                form4.ShowDialog() ' Form4'ü modal olarak aç
            Else
                MessageBox.Show("Girilen RefNo'ya sahip kayıt bulunamadı!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        ElseIf radioBtnTumBilgiler.Checked Then
            Dim form3 As New Form3()
            form3.ShowDialog()
        Else
            MessageBox.Show("Lütfen bir seçim yapın!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub radioBtnTumBilgiler_CheckedChanged(sender As Object, e As EventArgs) Handles radioBtnTumBilgiler.CheckedChanged
        btnRaporla.Enabled = radioBtnTumBilgiler.Checked OrElse radioBtnArananKayit.Checked
    End Sub

    Private Sub radioBtnArananKayit_CheckedChanged(sender As Object, e As EventArgs) Handles radioBtnArananKayit.CheckedChanged
        btnRaporla.Enabled = radioBtnTumBilgiler.Checked OrElse radioBtnArananKayit.Checked
    End Sub

End Class