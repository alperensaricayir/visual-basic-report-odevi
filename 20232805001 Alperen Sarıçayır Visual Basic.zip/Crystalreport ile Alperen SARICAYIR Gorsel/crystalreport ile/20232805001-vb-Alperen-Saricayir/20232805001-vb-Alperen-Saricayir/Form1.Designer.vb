﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHosGeldiniz = New System.Windows.Forms.Label()
        Me.checkBox1 = New System.Windows.Forms.CheckBox()
        Me.pbKareKod = New System.Windows.Forms.PictureBox()
        Me.pbOgrenciResmi = New System.Windows.Forms.PictureBox()
        Me.btnGiris = New System.Windows.Forms.Button()
        Me.txtSifre = New System.Windows.Forms.TextBox()
        Me.txtKullaniciAdi = New System.Windows.Forms.TextBox()
        Me.lblSifre = New System.Windows.Forms.Label()
        Me.lblKullaniciAdi = New System.Windows.Forms.Label()
        CType(Me.pbKareKod, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbOgrenciResmi, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHosGeldiniz
        '
        Me.lblHosGeldiniz.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.lblHosGeldiniz.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblHosGeldiniz.Location = New System.Drawing.Point(394, 90)
        Me.lblHosGeldiniz.Name = "lblHosGeldiniz"
        Me.lblHosGeldiniz.Size = New System.Drawing.Size(478, 96)
        Me.lblHosGeldiniz.TabIndex = 22
        Me.lblHosGeldiniz.Text = "HOŞ GELDİNİZ."
        Me.lblHosGeldiniz.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'checkBox1
        '
        Me.checkBox1.AutoSize = True
        Me.checkBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.checkBox1.Location = New System.Drawing.Point(521, 200)
        Me.checkBox1.Name = "checkBox1"
        Me.checkBox1.Size = New System.Drawing.Size(198, 33)
        Me.checkBox1.TabIndex = 21
        Me.checkBox1.Text = "Şifreyi Göster"
        Me.checkBox1.UseVisualStyleBackColor = True
        '
        'pbKareKod
        '
        Me.pbKareKod.Dock = System.Windows.Forms.DockStyle.Right
        Me.pbKareKod.Location = New System.Drawing.Point(950, 0)
        Me.pbKareKod.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.pbKareKod.Name = "pbKareKod"
        Me.pbKareKod.Size = New System.Drawing.Size(288, 471)
        Me.pbKareKod.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbKareKod.TabIndex = 20
        Me.pbKareKod.TabStop = False
        '
        'pbOgrenciResmi
        '
        Me.pbOgrenciResmi.Dock = System.Windows.Forms.DockStyle.Left
        Me.pbOgrenciResmi.Location = New System.Drawing.Point(0, 0)
        Me.pbOgrenciResmi.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.pbOgrenciResmi.Name = "pbOgrenciResmi"
        Me.pbOgrenciResmi.Size = New System.Drawing.Size(210, 471)
        Me.pbOgrenciResmi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbOgrenciResmi.TabIndex = 19
        Me.pbOgrenciResmi.TabStop = False
        '
        'btnGiris
        '
        Me.btnGiris.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnGiris.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.btnGiris.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnGiris.Location = New System.Drawing.Point(663, 329)
        Me.btnGiris.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btnGiris.Name = "btnGiris"
        Me.btnGiris.Size = New System.Drawing.Size(187, 84)
        Me.btnGiris.TabIndex = 18
        Me.btnGiris.Text = "GİRİŞ"
        Me.btnGiris.UseVisualStyleBackColor = False
        '
        'txtSifre
        '
        Me.txtSifre.Location = New System.Drawing.Point(521, 286)
        Me.txtSifre.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.txtSifre.Name = "txtSifre"
        Me.txtSifre.Size = New System.Drawing.Size(329, 35)
        Me.txtSifre.TabIndex = 17
        '
        'txtKullaniciAdi
        '
        Me.txtKullaniciAdi.Location = New System.Drawing.Point(521, 240)
        Me.txtKullaniciAdi.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.txtKullaniciAdi.Name = "txtKullaniciAdi"
        Me.txtKullaniciAdi.Size = New System.Drawing.Size(329, 35)
        Me.txtKullaniciAdi.TabIndex = 16
        '
        'lblSifre
        '
        Me.lblSifre.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblSifre.Location = New System.Drawing.Point(449, 286)
        Me.lblSifre.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblSifre.Name = "lblSifre"
        Me.lblSifre.Size = New System.Drawing.Size(68, 29)
        Me.lblSifre.TabIndex = 15
        Me.lblSifre.Text = "Şifre"
        Me.lblSifre.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblKullaniciAdi
        '
        Me.lblKullaniciAdi.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblKullaniciAdi.Location = New System.Drawing.Point(359, 244)
        Me.lblKullaniciAdi.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblKullaniciAdi.Name = "lblKullaniciAdi"
        Me.lblKullaniciAdi.Size = New System.Drawing.Size(158, 29)
        Me.lblKullaniciAdi.TabIndex = 14
        Me.lblKullaniciAdi.Text = "Kullanıcı Adı"
        Me.lblKullaniciAdi.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(15.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.ClientSize = New System.Drawing.Size(1238, 471)
        Me.Controls.Add(Me.lblHosGeldiniz)
        Me.Controls.Add(Me.checkBox1)
        Me.Controls.Add(Me.pbKareKod)
        Me.Controls.Add(Me.pbOgrenciResmi)
        Me.Controls.Add(Me.btnGiris)
        Me.Controls.Add(Me.txtSifre)
        Me.Controls.Add(Me.txtKullaniciAdi)
        Me.Controls.Add(Me.lblSifre)
        Me.Controls.Add(Me.lblKullaniciAdi)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        CType(Me.pbKareKod, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbOgrenciResmi, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents lblHosGeldiniz As System.Windows.Forms.Label
    Private WithEvents checkBox1 As System.Windows.Forms.CheckBox
    Private WithEvents pbKareKod As System.Windows.Forms.PictureBox
    Private WithEvents pbOgrenciResmi As System.Windows.Forms.PictureBox
    Private WithEvents btnGiris As System.Windows.Forms.Button
    Private WithEvents txtSifre As System.Windows.Forms.TextBox
    Private WithEvents txtKullaniciAdi As System.Windows.Forms.TextBox
    Private WithEvents lblSifre As System.Windows.Forms.Label
    Private WithEvents lblKullaniciAdi As System.Windows.Forms.Label

End Class
