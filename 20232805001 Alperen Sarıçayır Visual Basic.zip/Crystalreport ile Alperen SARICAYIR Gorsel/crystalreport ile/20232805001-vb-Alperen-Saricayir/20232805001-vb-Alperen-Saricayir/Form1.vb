﻿Imports System.Data.OleDb
Imports MessagingToolkit.QRCode.Codec

Public Class Form1
    Private Sub btnGiris_Click(sender As Object, e As EventArgs) Handles btnGiris.Click
        Dim kullaniciAdi As String = txtKullaniciAdi.Text.Trim()
        Dim sifre As String = txtSifre.Text.Trim()

        If String.IsNullOrEmpty(kullaniciAdi) Then
            MessageBox.Show("Kullanıcı adı boş olamaz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        If String.IsNullOrEmpty(sifre) Then
            MessageBox.Show("Şifre boş olamaz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kullanicilar.accdb;"
        Using conn As New OleDbConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT COUNT(*) FROM Kullanicilar WHERE KullaniciAdi = ? AND Sifre = ?"
                Using cmd As New OleDbCommand(query, conn)
                    cmd.Parameters.AddWithValue("@KullaniciAdi", kullaniciAdi)
                    cmd.Parameters.AddWithValue("@Sifre", sifre)
                    Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())

                    If count > 0 Then
                        MessageBox.Show("Başarılı giriş!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Dim form2 As New Form2()
                        form2.Show()
                        Me.Hide()
                    Else
                        MessageBox.Show("Hatalı kullanıcı adı veya şifre!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        txtKullaniciAdi.Clear()
                        txtSifre.Clear()
                        txtKullaniciAdi.Focus()
                    End If
                End Using
            Catch ex As Exception
                MessageBox.Show("Veritabanı bağlantı hatası: " & ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If checkBox1.Checked Then
            txtSifre.PasswordChar = ControlChars.NullChar ' Şifreyi göster
        Else
            txtSifre.PasswordChar = "*"c ' Şifreyi gizle
        End If
        Try
            Dim qrGenerator As New QRCodeEncoder()
            Dim qrImage As Bitmap = qrGenerator.Encode("ALPEREN SARICAYIR")
            pbKareKod.Image = qrImage
            pbKareKod.SizeMode = PictureBoxSizeMode.AutoSize
        Catch ex As Exception
            MessageBox.Show("QR Kod oluşturulurken hata oluştu: " & ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        pbOgrenciResmi.SizeMode = PictureBoxSizeMode.AutoSize
        pbOgrenciResmi.Image = Image.FromFile("alperen-vesikalik-saricayir-20232805001.png")


    End Sub

    Private Sub checkBox1_CheckedChanged(sender As Object, e As EventArgs) Handles checkBox1.CheckedChanged
        If checkBox1.Checked Then
            txtSifre.PasswordChar = ControlChars.NullChar ' Şifreyi göster
        Else
            txtSifre.PasswordChar = "*"c ' Şifreyi gizle
        End If

    End Sub

    Private Sub pbOgrenciResmi_Click(sender As Object, e As EventArgs) Handles pbOgrenciResmi.Click

    End Sub

    Private Sub pbKareKod_Click(sender As Object, e As EventArgs) Handles pbKareKod.Click
        
    End Sub
End Class