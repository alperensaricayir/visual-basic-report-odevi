﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dataGridView1 = New System.Windows.Forms.DataGridView()
        Me.radioBtnArananKayit = New System.Windows.Forms.RadioButton()
        Me.radioBtnTumBilgiler = New System.Windows.Forms.RadioButton()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.btnRaporla = New System.Windows.Forms.Button()
        Me.btnSil = New System.Windows.Forms.Button()
        Me.btnKaydet = New System.Windows.Forms.Button()
        Me.comboMemleket = New System.Windows.Forms.ComboBox()
        Me.txtGider = New System.Windows.Forms.TextBox()
        Me.txtGelir = New System.Windows.Forms.TextBox()
        Me.txtMusteriSoyadi = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.txtMusteriAdi = New System.Windows.Forms.TextBox()
        CType(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dataGridView1
        '
        Me.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.dataGridView1.Location = New System.Drawing.Point(0, 332)
        Me.dataGridView1.Name = "dataGridView1"
        Me.dataGridView1.RowTemplate.Height = 28
        Me.dataGridView1.Size = New System.Drawing.Size(1138, 389)
        Me.dataGridView1.TabIndex = 31
        '
        'radioBtnArananKayit
        '
        Me.radioBtnArananKayit.AutoSize = True
        Me.radioBtnArananKayit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.radioBtnArananKayit.Location = New System.Drawing.Point(410, 284)
        Me.radioBtnArananKayit.Name = "radioBtnArananKayit"
        Me.radioBtnArananKayit.Size = New System.Drawing.Size(232, 33)
        Me.radioBtnArananKayit.TabIndex = 30
        Me.radioBtnArananKayit.TabStop = True
        Me.radioBtnArananKayit.Text = "Seçileni Raporla"
        Me.radioBtnArananKayit.UseVisualStyleBackColor = True
        '
        'radioBtnTumBilgiler
        '
        Me.radioBtnTumBilgiler.AutoSize = True
        Me.radioBtnTumBilgiler.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.radioBtnTumBilgiler.Location = New System.Drawing.Point(410, 245)
        Me.radioBtnTumBilgiler.Name = "radioBtnTumBilgiler"
        Me.radioBtnTumBilgiler.Size = New System.Drawing.Size(287, 33)
        Me.radioBtnTumBilgiler.TabIndex = 29
        Me.radioBtnTumBilgiler.TabStop = True
        Me.radioBtnTumBilgiler.Text = "Tüm Bilgileri Raporla"
        Me.radioBtnTumBilgiler.UseVisualStyleBackColor = True
        '
        'label5
        '
        Me.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label5.Location = New System.Drawing.Point(38, 200)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(127, 29)
        Me.label5.TabIndex = 28
        Me.label5.Text = "Memleket"
        Me.label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'label4
        '
        Me.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label4.Location = New System.Drawing.Point(87, 159)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(78, 29)
        Me.label4.TabIndex = 27
        Me.label4.Text = "Gider"
        Me.label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'label3
        '
        Me.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label3.Location = New System.Drawing.Point(95, 118)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(70, 29)
        Me.label3.TabIndex = 26
        Me.label3.Text = "Gelir"
        Me.label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'label2
        '
        Me.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label2.Location = New System.Drawing.Point(60, 77)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(105, 29)
        Me.label2.TabIndex = 25
        Me.label2.Text = "Soyisim"
        Me.label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'btnRaporla
        '
        Me.btnRaporla.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnRaporla.Enabled = False
        Me.btnRaporla.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnRaporla.Location = New System.Drawing.Point(410, 173)
        Me.btnRaporla.Name = "btnRaporla"
        Me.btnRaporla.Size = New System.Drawing.Size(174, 64)
        Me.btnRaporla.TabIndex = 24
        Me.btnRaporla.Text = "RAPORLA"
        Me.btnRaporla.UseVisualStyleBackColor = False
        '
        'btnSil
        '
        Me.btnSil.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnSil.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSil.Location = New System.Drawing.Point(410, 103)
        Me.btnSil.Name = "btnSil"
        Me.btnSil.Size = New System.Drawing.Size(174, 64)
        Me.btnSil.TabIndex = 23
        Me.btnSil.Text = "SİL"
        Me.btnSil.UseVisualStyleBackColor = False
        '
        'btnKaydet
        '
        Me.btnKaydet.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnKaydet.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnKaydet.Location = New System.Drawing.Point(410, 33)
        Me.btnKaydet.Name = "btnKaydet"
        Me.btnKaydet.Size = New System.Drawing.Size(174, 64)
        Me.btnKaydet.TabIndex = 22
        Me.btnKaydet.Text = "KAYDET"
        Me.btnKaydet.UseVisualStyleBackColor = False
        '
        'comboMemleket
        '
        Me.comboMemleket.FormattingEnabled = True
        Me.comboMemleket.Location = New System.Drawing.Point(171, 197)
        Me.comboMemleket.Name = "comboMemleket"
        Me.comboMemleket.Size = New System.Drawing.Size(222, 37)
        Me.comboMemleket.TabIndex = 21
        '
        'txtGider
        '
        Me.txtGider.Location = New System.Drawing.Point(171, 156)
        Me.txtGider.Name = "txtGider"
        Me.txtGider.Size = New System.Drawing.Size(222, 35)
        Me.txtGider.TabIndex = 20
        '
        'txtGelir
        '
        Me.txtGelir.Location = New System.Drawing.Point(171, 115)
        Me.txtGelir.Name = "txtGelir"
        Me.txtGelir.Size = New System.Drawing.Size(222, 35)
        Me.txtGelir.TabIndex = 19
        '
        'txtMusteriSoyadi
        '
        Me.txtMusteriSoyadi.Location = New System.Drawing.Point(171, 74)
        Me.txtMusteriSoyadi.Name = "txtMusteriSoyadi"
        Me.txtMusteriSoyadi.Size = New System.Drawing.Size(222, 35)
        Me.txtMusteriSoyadi.TabIndex = 18
        '
        'label1
        '
        Me.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label1.Location = New System.Drawing.Point(104, 36)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(61, 29)
        Me.label1.TabIndex = 17
        Me.label1.Text = "İsim"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtMusteriAdi
        '
        Me.txtMusteriAdi.Location = New System.Drawing.Point(171, 30)
        Me.txtMusteriAdi.Name = "txtMusteriAdi"
        Me.txtMusteriAdi.Size = New System.Drawing.Size(222, 35)
        Me.txtMusteriAdi.TabIndex = 16
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(15.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.ClientSize = New System.Drawing.Size(1138, 721)
        Me.Controls.Add(Me.dataGridView1)
        Me.Controls.Add(Me.radioBtnArananKayit)
        Me.Controls.Add(Me.radioBtnTumBilgiler)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.btnRaporla)
        Me.Controls.Add(Me.btnSil)
        Me.Controls.Add(Me.btnKaydet)
        Me.Controls.Add(Me.comboMemleket)
        Me.Controls.Add(Me.txtGider)
        Me.Controls.Add(Me.txtGelir)
        Me.Controls.Add(Me.txtMusteriSoyadi)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.txtMusteriAdi)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form2"
        CType(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents dataGridView1 As System.Windows.Forms.DataGridView
    Private WithEvents radioBtnArananKayit As System.Windows.Forms.RadioButton
    Private WithEvents radioBtnTumBilgiler As System.Windows.Forms.RadioButton
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents btnRaporla As System.Windows.Forms.Button
    Private WithEvents btnSil As System.Windows.Forms.Button
    Private WithEvents btnKaydet As System.Windows.Forms.Button
    Private WithEvents comboMemleket As System.Windows.Forms.ComboBox
    Private WithEvents txtGider As System.Windows.Forms.TextBox
    Private WithEvents txtGelir As System.Windows.Forms.TextBox
    Private WithEvents txtMusteriSoyadi As System.Windows.Forms.TextBox
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents txtMusteriAdi As System.Windows.Forms.TextBox
End Class
